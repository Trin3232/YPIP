<footer>
  <p id="comp-intel-prop"> Copyright &copy;
    <span id="update-year-text"></span>
    &nbsp; Your Partner In Property&nbsp; |&nbsp; All Rights Reserved |&nbsp; Web Design By <a id="link-k" href="" target="_blank">(link)</a> &nbsp;
    <a href="https://github.com/Trin3232" target="_blank" title="GitHub">
      <i id="fa-git-icon", class="fab fa-github fa-lg"></i>
    </a>&nbsp;
    <a href="https://www.facebook.com/itsjohnkerr" target="_blank" title="Facebook">
      <i class="fab fa-facebook fa-lg"></i>
    </a>&nbsp;
    <a href="https://www.meetup.com/Serviced-Accommodation-Group/ target="_blank" title="Meetup">
      <i class="fab fa-meetup fa-lg"></i>
    </a>&nbsp;
    <a href="https://twitter.com/itsjohnkerr" target="_blank" title="Twitter">
      <i class="fab fa-twitter fa-lg"></i>
    </a>&nbsp;
    <a href="https://www.linkedin.com/in/itsjohnkerr" target="_blank" title="LinkedIn">
      <i class="fab fa-linkedin fa-lg"></i>
    </a>&nbsp;
    <a href="https://www.youtube.com/channel/UC_SkcG95ChtLIK9IRjrvcqw" target="_blank" title="YouTube"><i class="fab fa-youtube fa-lg"></i>
    </a>&nbsp;
  </p>
</footer>

  <!-- Script Links -->

  <script src="https://code.jquery.com/jquery-latest.min.js" integrity="sha384-UM1JrZIpBwVf5jj9dTKVvGiiZPZTLVoq4sfdvIe9SBumsvCuv6AHDNtEiIb5h1kU" crossorigin="anonymous"></script>
  <script src="'/script.js'"></script>

  <?php wp_footer(); ?>

 </body>
</html>
