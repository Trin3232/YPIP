wp_enqueue_script( 'script', get_template_directory_uri() . '/script.js', array ( 'jquery' ), 1.0, true);

<!--https://developer.wordpress.org/themes/basics/including-css-javascript/#default-scripts-included-and-registered-by-wordpress -->
<!-- https://www.wpbeginner.com/wp-tutorials/how-to-properly-add-javascripts-and-styles-in-wordpress/ -->
