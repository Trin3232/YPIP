<div class="container">
  <h1>Welcome to Your Partner In Property</h1>
</div>
</section>
<!--INFO SECTION -->
<div id="container-2">
  <section id="pic-info">
    <img class="jk1" src="../Images/Profile Pics/John Kerr Sofa facing original.jpg" alt="John Sofa Facing Front"/>
    <div class="box-info">
      <h2 class="short-info-h2">Lorem Ipsum</h2>
        <ul class="short-info">
          <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Temporibus, quaerat.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel, natus?</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ea, et?</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora, accusantium!</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quibusdam, optio!</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. In, doloribus.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. In, doloribus.</li>
        </ul>
    </div>
  </section>
</div>
