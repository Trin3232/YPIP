</div>
<footer>
  <p id="comp-intel-prop"> Copyright &copy;
    <span id="update-year-text"></span>
    &nbsp; Your Partner In Property&nbsp; |&nbsp; All Rights Reserved |&nbsp; Web Design By <a id="link-k" href="" target="_blank">(link)</a> &nbsp;
    <a href="https://github.com/Trin3232" target="_blank">
      <i id="fa-git-icon", class="fab fa-github fa-lg"></i>
    </a>&nbsp;|
    <a href="https://www.facebook.com/" target="_blank">
      <i class="fab fa-facebook fa-lg"></i>
    </a>&nbsp;|
    <a href="https://www.meetup.com/" target="_blank">
      <i class="fab fa-meetup fa-lg"></i>
    </a>&nbsp;|
  </p>
</footer>
<!-- Script Links -->
<script src="https://code.jquery.com/jquery-latest.min.js" integrity="sha384-UM1JrZIpBwVf5jj9dTKVvGiiZPZTLVoq4sfdvIe9SBumsvCuv6AHDNtEiIb5h1kU" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.1/semantic.min.js" integrity="sha384-d0+ufSr6Y7eU5V6E8Bt1AioIn4ParGkr0AwQ5RZD/S2mTaiEXMV78mqaYKMLE2qv" crossorigin="anonymous"></script>
<script src="../JS/main.js"></script>
<?php wp_footer();?>
</body>
</html>
